package com.example.test_app

data class SignupRequest(
    val username: String,
    val email: String,
    val password: String
)
